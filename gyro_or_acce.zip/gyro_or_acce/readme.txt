Installer les 2 librairies
Faire votre branchement avec le MPU6050
T�l�verser votre code
Afficher le serial print