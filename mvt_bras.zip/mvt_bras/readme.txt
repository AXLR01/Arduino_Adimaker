Librairies: inclure wire.h, Braccio.h et Servo.h
Brancher votre bras robot braccio avec sont shield sur votre arduino
Lancer le metter me code sur votre arduino
/!\ Il est possible que vous ayez invers� les moteurs, jouer donc sur l'ordre
des donn�es de la commande Braccio.ServoMovement
/!\ Il est possible qu'il y est une erreur de calcule