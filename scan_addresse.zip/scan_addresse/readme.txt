Permet de connaitre l'addresse d'un capteur arduino brnach� en I2C

Faire votre montage normalement avec votre capteur correctement brancher en I2C
donc 1 fil sur SCL ( serial clock line ) et 1 sur le port SDA ( serial data line )

Ouvrire le code dans un ide arduino, le telerverser, afficher le serial print