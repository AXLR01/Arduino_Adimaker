librairie: Wire.h
Faire votre branchement avec votre capteur � ultrason
Ouvrire le code dans un �diteur
Ne pas oublier d'indiquer dans le code le pin utilis�