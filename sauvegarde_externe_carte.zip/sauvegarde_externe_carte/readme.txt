librairie nnecessaire SD.h
Faire votre branchement avec les ports suivant:
Cs sur le port 10
D1 sur le port 11
D0 sur le port 12
CLK sur le port 13
Formater votre carte avec le logiciel guiformat-x64.exe
Brancher votre arduino et lacer le code