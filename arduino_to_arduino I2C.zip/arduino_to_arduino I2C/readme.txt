librairie inclure Wire.h
Brancher le port SDA du maitre sur celui de l'esclave, pareil pour le SCL
Telverser le code du maitre sur le maitre
Televerser le code de l'esclave sur l'esclave
Ouvrire les serial print  